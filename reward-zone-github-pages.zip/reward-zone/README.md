# Reward Zone

Mobile-friendly black-and-orange front-end demo for GitHub Pages.

## Current demo behavior
- Select reward type and amount from ₹1 to ₹500.
- If there is no code inventory, the site clearly says **No code available**.
- It does not fabricate random redeem codes.

## Important limitation
GitHub Pages serves static front-end files only. It cannot safely host a private admin panel or securely store/manage redeem-code inventory by itself. To make the requested flow work — admin adds real codes, and users receive only those exact codes for the selected reward and amount, once each — connect a secure backend/database (for example, Firebase Authentication + Firestore with server-side rules or a trusted server function). Do not place admin passwords, private keys, or the full code inventory in public HTML/JavaScript files.

## Publish the front-end demo
1. Create a GitHub repository such as `reward-zone`.
2. Upload `index.html` and `README.md` to the repository root.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
5. GitHub will show the published URL when deployment completes.
